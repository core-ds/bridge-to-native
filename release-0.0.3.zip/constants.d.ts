import { NativeFeaturesFromVersion } from './types';
export declare const CLOSE_WEBVIEW_SEARCH_KEY = "closeWebView";
export declare const CLOSE_WEBVIEW_SEARCH_VALUE = "true";
export declare const PREVIOUS_B2N_STATE_STORAGE_KEY = "previousBridgeToNativeState";
export declare const PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY = "previousNativeNavigationAndTitleState";
export declare const versionToIosAppId: {
    readonly '0.0.0': "YWxmYWJhbms=";
    readonly '12.22.0': "YWNvbmNpZXJnZQ==";
    readonly '12.26.0': "a2l0dHljYXNo";
    readonly '12.31.0': "YXdlYXNzaXN0";
};
export declare const nativeFeaturesFromVersion: NativeFeaturesFromVersion;
