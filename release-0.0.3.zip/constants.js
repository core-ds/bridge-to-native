"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeFeaturesFromVersion = exports.versionToIosAppId = exports.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY = exports.PREVIOUS_B2N_STATE_STORAGE_KEY = exports.CLOSE_WEBVIEW_SEARCH_VALUE = exports.CLOSE_WEBVIEW_SEARCH_KEY = void 0;
exports.CLOSE_WEBVIEW_SEARCH_KEY = 'closeWebView';
exports.CLOSE_WEBVIEW_SEARCH_VALUE = 'true';
exports.PREVIOUS_B2N_STATE_STORAGE_KEY = 'previousBridgeToNativeState';
exports.PREVIOUS_NATIVE_NAVIGATION_AND_TITLE_STATE_STORAGE_KEY = 'previousNativeNavigationAndTitleState';
exports.versionToIosAppId = {
    '0.0.0': 'YWxmYWJhbms=',
    '12.22.0': 'YWNvbmNpZXJnZQ==',
    '12.26.0': 'a2l0dHljYXNo',
    '12.31.0': 'YXdlYXNzaXN0',
};
exports.nativeFeaturesFromVersion = {
    android: {
        linksInBrowser: {
            nativeFeatureFtKey: 'linksInBrowserAndroid',
            fromVersion: '11.71.0',
        },
        geolocation: { fromVersion: '11.71.0' },
    },
    ios: {
        linksInBrowser: {
            nativeFeatureFtKey: 'linksInBrowserIos',
            fromVersion: '13.3.0',
        },
        geolocation: { fromVersion: '0.0.0' },
    },
};
