import type { BridgeToNative } from '.';
import { PdfType } from './types';
/**
 * Класс содержит реализацию обходных путей для веб-фич, которые не работают в нативном-вебвью.
 */
export declare class NativeFallbacks {
    private b2n;
    constructor(b2n: BridgeToNative);
    /**
     * Метод, возвращающий пропсы для ссылок, ведущих на ВНЕШНИЙ ресурс. Которые просто
     * нужно «подмешать» к ссылке в JSX:
     *
     * ```
     * <a {...bridgeToNative.nativeFallbacks.getExternalLinkProps('https://ya.ru')}>Link to external feature</a>
     * ```
     * Либо просто достать интересующие поля - onClick или href
     * ```
     * const {onClick, href} = bridgeToNative.nativeFallbacks.getExternalLinkProps(url, clickHandler)
     * document.querySelector('.myLink').onclick = onClick;
     * <a {...bridgeToNative.nativeFallbacks.getExternalLinkProps('https://ya.ru')}>Link to external feature</a>
     * ```
     * В разных OS и разных версиях приложения, открытие ресурса будет работать по-разному:
     *
     * - Если текущая версия приложения может открыть ссылку в браузере,
     *  обогащаем URL специальным query-параметром (`target=_blank` в приложении не работает).
     * - Если это iOS, меняем URL на диплинк, который откроет ссылку в новом вебвью, поверх текущего.
     *  К первому-вебвью, пользователь вернётся, когда закроет второе вебвью с внешним ресурсом.
     * - В старых приложениях на Андроид – URL не меняем, но добавляем `onClick` для сбрасывания синхронизации
     *  навигации с приложением. Это «фолбэк-сценарий» с плохим UX (сайт полностью выпадает из истории), но другого способа нет.
     *
     * @param link Строка - валидный урл.
     * @param onClick Дополнительный обработчик на клик, например, для отправки метрики.
     *  Внимание! Не факт, что в «фолбэк-сценарии» асинхронная операция будет выполнена (метрика отправлена)!
     * @returns Пропсы для ссылки в вебвью окружении.
     */
    getExternalLinkProps(link: string, onClick?: () => void): {
        href: string;
        onClick: (() => void) | undefined;
    };
    /**
     * Метод для открытия PDF в нативном вьювере.
     *
     * Есть нюансы с версиями приложения, OS устройства.
     * Надо тестировать по моде статистики.
     *
     * @param url ссылка на pdf
     * @param type тип pdf ссылки
     * @param title название pdf файла
     */
    openPdf(url: string, type?: PdfType, title?: string): void;
    /**
     * Метод, для перехода на ВНЕШНИЙ ресурс.
     *
     * См. описание в `getExternalLinkProps`, чтобы узнать, как выбирается способ для перехода.
     *
     * @param link Строка - валидный урл.
     */
    visitExternalResource(link: string): void;
}
