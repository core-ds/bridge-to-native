"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidVersionFormat = exports.getUrlInstance = exports.extractAppNameRouteAndQuery = void 0;
/**
 * Разделяет веб ссылку на компоненты
 * @param route внутренний путь для навигации
 * @return объект с appName, route, query
 */
const extractAppNameRouteAndQuery = (route) => {
    var _a;
    let appName = '';
    let path = '';
    let query;
    const clearedPath = route.replace(/(?:^\/)|(?:\/$)/g, '');
    const segments = clearedPath.split('/');
    const queryByPath = clearedPath.split('?')[1];
    appName = ((_a = segments.shift()) === null || _a === void 0 ? void 0 : _a.split('?')[0]) || '';
    if (queryByPath) {
        query = Array.from(new URLSearchParams(queryByPath).entries()).reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
    }
    path = segments.join('/').replace(`?${queryByPath}`, '');
    return { appName, path, query };
};
exports.extractAppNameRouteAndQuery = extractAppNameRouteAndQuery;
/**
 * Возвращает экземпляр `URL` из ссылки, докидывая `https://` при отсутствии.
 */
const getUrlInstance = (link) => {
    const protocolRequiredPattern = /^https?:\/\//;
    let url;
    if (protocolRequiredPattern.test(link)) {
        url = new URL(link);
    }
    else {
        try {
            // Пробуем докинуть `https://`, как правило, это помогает.
            url = new URL(`https://${link}`);
        }
        catch (e) {
            // Кажется, добавив протокол, сюда мы больше не сможем вывалиться, но на всякий случай...
            url = new URL('about:blank');
        }
    }
    return url;
};
exports.getUrlInstance = getUrlInstance;
/**
 * Проверяет, что переданная строка содержит версию приложения в правильном формате.
 *
 * @param version Строка с версией для проверки.
 * @returns Правильный формат или нет.
 */
const isValidVersionFormat = (version) => {
    if (!version)
        return false;
    const versionPattern = /^\d+\.\d+\.\d+$/;
    return versionPattern.test(version);
};
exports.isValidVersionFormat = isValidVersionFormat;
