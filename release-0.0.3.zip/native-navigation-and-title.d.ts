import { BridgeToNative } from '.';
export declare type HandleRedirect = (appName: string, path?: string, params?: Record<string, string>) => void;
/**
 * Класс, отвечающий за взаимодействие с нативными элементами в приложении – заголовком
 * и нативной кнопкой назад.
 */
export declare class NativeNavigationAndTitle {
    private b2n;
    private nativeHistoryStack;
    private numOfBackSteps;
    private lastSetPageSettingsParams;
    private handleWindowRedirect;
    constructor(b2n: BridgeToNative, pageId: number | null, initialNativeTitle: string | undefined, handleWindowRedirect: HandleRedirect);
    /**
     * Метод, вызывающий `history.back()` или закрывающий вебвью, если нет записей
     * в истории переходов.
     */
    goBack(): void;
    /**
     * Метод, вызывающий history.go(-колл. шагов назад) и модифицирует внутреннее
     * состояние, чтобы в дальнейшем зарегистририровать этот переход в приложении.
     *
     * @param stepsNumber Количество шагов назад.
     *  Возможно передача как положительного, так и отрицательного числа.
     *  0 будет проигнорирован.
     * @param autocloseWebview Флаг – закрывать ли вебвью автоматически,
     *  если переданное кол-во шагов будет больше, чем записей в истории.
     */
    goBackAFewSteps(stepsNumber: number, autocloseWebview?: boolean): void;
    /**
     * @param path Путь для перехода на функциональность внутри приложения.
     */
    handleRedirect(path: string): void;
    /**
     * В этом варианте аргументы 2,3,4 соответствуют аргументам 1,2,3 метода `src/shared/utils/handle-redirect`.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в приложении.
     * @param appName См. первый параметр `src/handle-redirect.ts`.
     * @param path См. второй параметр `src/handle-redirect.ts`.
     * @param params См. третий параметр `src/handle-redirect.ts`.
     */
    handleRedirect(pageTitle: string, appName: string, path?: string, params?: Record<string, string>): void;
    /**
     * Информирует натив, что веб находится на первом экране (сбрасывает историю переходов, не влияя на браузерную
     * историю), а значит следующее нажатие на кнопку "Назад" в нативне закроет вебвью.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в нативе.
     */
    setInitialView(pageTitle?: string): void;
    /**
     * Метод для смены заголовка в нативе без влияния на историю переходов.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в нативе.
     */
    setTitle(pageTitle: string): void;
    /**
     * Метод для открытия второго web приложения в рамках
     * одной вебвью сессии
     * сохраняет все текущее состояние текущего экземпляра bridgeToAm и AmNavigationAndTitle в sessionStorage, а
     * так же наполняет url необходимыми query параметрами. Работает только в Android окружении.
     * В IOS окружении будет открыто новое webview поверх текущего.
     * @param url адрес второго web приложения к которому перед переходом на него будут добавлены
     * все initial query параметры от натива и параметр nextPageId (Android)
     */
    navigateInsideASharedSession(url: string): void;
    /**
     * ПОКА НЕ ИСПОЛЬЗОВАТЬ В ПРОДЕ (МЕТОД НЕ РАБОТАЕТ КОРРЕКТНО НА ANDROID)
     * НА ANDROID ПРИ ПЕРЕЗАГРУЗКЕ СТРАНИЦЫ В ИСТРИЮ ЛОЖИТСЯ + ЕЩЕ ОДИН ЛИШНИЙ ЭЛЕМЕНТ
     * Данный метод будет дорабатываться отдельной задачей
     * Безопасный способ для перезагрузки страницы.
     * Производит предварительное сохранение текущего состояния
     * BridgeToNative и NativeNavigationAndTitle перед вызовом location.reload()
     */
    reloadPage(): void;
    /**
     * Метод для сохранения текущего состояния NativeNavigationAndTitle в sessionStorage.
     */
    private saveCurrentState;
    /**
     * Метод, вычисляющий `pageId`, который нужно послать в приложение
     * для правильной синхронизации с нативной-кнопкой "Назад".
     *
     * @param purpose Цель взаимодействия с приложением.
     * @returns Правильный pageId.
     */
    private getNativePageId;
    /**
     * Вспомогательный метод для `getNativePageId` initialization кейса.
     *
     * @returns Правильный pageId.
     */
    private getNativePageIdForInitialization;
    /**
     * Вспомогательный метод для `getNativePageId` navigation кейса.
     *
     * @returns Правильный pageId.
     */
    private getNativePageIdForNavigation;
    /**
     * Вспомогательный метод для `getNativePageId` only-title кейса.
     *
     * @returns Правильный pageId.
     */
    private getNativePageIdForTitleReplacing;
    /**
     * Обработчик для `window.onpopstate` события. Который сработает
     * после нажатия на кнопку "Назад" в нативе, вызова `history.back()` и `history.go(-x)`.
     */
    private handleBack;
    /**
     * Синхронизирует состояние истории переходов и заголовок с приложением.
     *
     * @param pageTitle Заголовок, который нужно отрисовать в приложении.
     * @param purpose Цель взаимодействия с приложением.
     */
    private syncHistoryWithNative;
    /**
     * Метод для перехода в веб из другого веб приложения в рамках
     * одной вебвью сессии
     * @param pageId - Номер текущего page который нужно отправить в приложение
     * @param title - Title текущего page который нужно отправить в приложение
     */
    private supportSharedSession;
    /**
     * Восстанавливает свое предыдущее состояние nativeHistoryStack и title из sessionStorage
     */
    private restorePreviousState;
    /**
     *  Вспомогательный метод для setInitialView, supportSharedSession
     *  переназначает обработчик @handleBack для `window.onpopstate` события
     */
    private reassignPopstateListener;
    /**
     * Вспомогательный метод для navigateInsideASharedSession.
     * Подготавливает внешнюю ссылку в рамках контракта для совместной работы веб-приложений в
     * рамках одной вебвью сессии
     * @param url - url иного веб приложения
     * @return подготовленная согласно контракту ссылка на иное веб приложение с initial query
     * параметрами от нативе, а так же nextPageId
     */
    private prepareExternalLinkBeforeOpen;
}
